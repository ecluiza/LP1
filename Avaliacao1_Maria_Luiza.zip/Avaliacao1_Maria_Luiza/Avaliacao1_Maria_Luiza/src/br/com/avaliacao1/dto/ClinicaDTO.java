/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.avaliacao1.dto;

/**
 *
 * @author maeca
 */
public class ClinicaDTO {
    
    private String nomepet_cli, nomeresp_cli, animal_cli, raca_cli, cpf_cli, rg_cli, numero_cli;
    private int id_cli;

    public String getNomepet_cli() {
        return nomepet_cli;
    }

    public void setNomepet_cli(String nomepet_cli) {
        this.nomepet_cli = nomepet_cli;
    }

    public String getNomeresp_cli() {
        return nomeresp_cli;
    }

    public void setNomeresp_cli(String nomeresp_cli) {
        this.nomeresp_cli = nomeresp_cli;
    }

    public String getAnimal_cli() {
        return animal_cli;
    }

    public void setAnimal_cli(String animal_cli) {
        this.animal_cli = animal_cli;
    }

    public String getRaca_cli() {
        return raca_cli;
    }

    public void setRaca_cli(String raca_cli) {
        this.raca_cli = raca_cli;
    }

    public String getCpf_cli() {
        return cpf_cli;
    }

    public void setCpf_cli(String cpf_cli) {
        this.cpf_cli = cpf_cli;
    }

    public String getRg_cli() {
        return rg_cli;
    }

    public void setRg_cli(String rg_cli) {
        this.rg_cli = rg_cli;
    }

    public String getNumero_cli() {
        return numero_cli;
    }

    public void setNumero_cli(String numero_cli) {
        this.numero_cli = numero_cli;
    }

    public int getId_cli() {
        return id_cli;
    }

    public void setId_cli(int id_cli) {
        this.id_cli = id_cli;
    }

    
}