/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.avaliacao1.dao;
import java.sql.*;
import br.com.avaliacao1.dto.ClinicaDTO;

/**
 *
 * @author maeca
 */
public class ClinicaDAO {
    
    public ClinicaDAO(){
        
    }
    
    private ResultSet rs = null;
    private Statement stmt = null;
    
        public boolean inserirClinica(ClinicaDTO clinicaDTO){
        try{
            ConexaoDAO.ConnectDB();
            stmt = ConexaoDAO.con.createStatement();
            
            String comando = "Insert into clinica (nomepet_cli, nomeresp_cli, animal_cli, "
                    +"raca_cli, rg_cli, cpf_cli, numero_cli) values("
                    +"'"+clinicaDTO.getNomepet_cli()+"',"
                    +"'"+clinicaDTO.getNomeresp_cli()+"',"
                    +"'"+clinicaDTO.getAnimal_cli()+"',"
                    +"'"+clinicaDTO.getRaca_cli()+"',"
                    +"'"+clinicaDTO.getRg_cli()+"',"
                    +"'"+clinicaDTO.getCpf_cli()+"',"
                    +"'"+clinicaDTO.getNumero_cli()+"')";
            
            System.out.println(comando);
            
            stmt.execute(comando.toUpperCase());
            ConexaoDAO.con.commit();
            stmt.close();
            return true;
        }
        catch(Exception e){
            System.out.println(e.getMessage());
            return false;
        }
        finally{
            ConexaoDAO.CloseDB();
        }
    }
        
    public ResultSet consultarClinica(ClinicaDTO clinicaDTO, int opcao){
       
        try{
            ConexaoDAO.ConnectDB();
            stmt = ConexaoDAO.con.createStatement();
            String comando = "";
            
            switch(opcao){
                case 1:
                    comando = "Select c.* "+
                              "from clinica c "+
                              "where nomepet_cli like '"+clinicaDTO.getNomepet_cli()+"%' "+
                              "order by c.nomepet_cli";
                break;
                case 2:
                    comando = "Select c.* "+
                              "from clinica c "+
                              "where c.id_cli = "+clinicaDTO.getId_cli();
                break;
                case 3:
                    comando = "Select c.id_cli, c.nomepet_cli "+
                              "from clinica c";
                
                break;
            }
            rs = stmt.executeQuery(comando.toUpperCase());
            return rs;
        }
        catch(Exception e){
            System.out.println(e.getMessage());
            return rs;
        }
    }
    
     public boolean alterarClinica(ClinicaDTO clinicaDTO){
       try{
            ConexaoDAO.ConnectDB();
            stmt = ConexaoDAO.con.createStatement();
            
            String comando = "Update clinica set "
                    +"nomepet_cli = '" +clinicaDTO.getNomepet_cli()+"', "
                    +"nomeresp_cli = '" +clinicaDTO.getNomeresp_cli()+"', "
                    +"animal_cli = '" +clinicaDTO.getAnimal_cli()+ "', "
                    +"raca_cli = '" +clinicaDTO.getRaca_cli()+ "', "
                    +"rg_cli = '" +clinicaDTO.getRg_cli()+ "', "
                    +"cpf_cli = '" +clinicaDTO.getCpf_cli()+ "', "
                    +"numero_cli = '" +clinicaDTO.getNumero_cli()+ "' "
                    +"where id_cli = " +clinicaDTO.getId_cli();
            
            System.out.println(comando);
            
            stmt.execute(comando.toUpperCase());
            ConexaoDAO.con.commit();
            stmt.close();
            return true;
        }
        catch(Exception e){
            System.out.println(e.getMessage());
            return false;
        }
        finally{
            ConexaoDAO.CloseDB();
        }
    }
     
     public boolean excluirClinica(ClinicaDTO clinicaDTO){
        try{
            ConexaoDAO.ConnectDB();
            stmt = ConexaoDAO.con.createStatement();
            
            String comando = "Delete from clinica where id_cli = "
                            + clinicaDTO.getId_cli();
            
            System.out.println(comando);
            
            stmt.execute(comando.toUpperCase());
            ConexaoDAO.con.commit();
            stmt.close();
            return true;
        }
        catch(Exception e){
            System.out.println(e.getMessage());
            return false;
        }
        finally{
            ConexaoDAO.CloseDB();
        }
    }
}//fecha a classe 
