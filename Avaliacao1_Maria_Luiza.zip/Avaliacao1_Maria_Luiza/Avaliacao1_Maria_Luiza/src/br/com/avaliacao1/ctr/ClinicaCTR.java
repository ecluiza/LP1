/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.avaliacao1.ctr;

import java.sql.ResultSet;
import br.com.avaliacao1.dto.ClinicaDTO;
import br.com.avaliacao1.dao.ClinicaDAO;
import br.com.avaliacao1.dao.ConexaoDAO;
/**
 *
 * @author maeca
 */
public class ClinicaCTR {
    
    ClinicaDAO clinicaDAO = new ClinicaDAO();
    
    public ClinicaCTR(){
        
    }
    
    public String inserirClinica(ClinicaDTO clinicaDTO){
        
        try{
            if(clinicaDAO.inserirClinica(clinicaDTO)){
                return "PET CADASTRADO COM SUCESSO";
            }else{
                return "PET NÃO CADASTRADO";
            }
        }
        catch(Exception e){
            System.out.println(e.getMessage());
            return "PET NÃO CADASTRADO";
        }
    }
    
     public ResultSet consultarClinica(ClinicaDTO clinicaDTO, int opcao){
        
        ResultSet rs = null;
        rs = clinicaDAO.consultarClinica(clinicaDTO, opcao);
        
        return rs;
    }
     
     public void CloseDB(){
        ConexaoDAO.CloseDB();
    }
     
     public String alterarClinica(ClinicaDTO clinicaDTO){
        
        try{
            if(clinicaDAO.alterarClinica(clinicaDTO)){
                return "CLIENTE ALTERADO COM SUCESSO";
            }else{
                return "CLIENTE NÃO ALTERADO";
            }
        }
        catch(Exception e){
            System.out.println(e.getMessage());
            return "CLIENTE NÃO ALTERADO";
        }
    }
     
      public String excluirClinica(ClinicaDTO clinicaDTO){
        
        try{
            if(clinicaDAO.excluirClinica(clinicaDTO)){
                return "CLIENTE EXCLUIDO COM SUCESSO";
            }else{
                return "CLIENTE NÃO EXCLUIDO";
            }
        }
        catch(Exception e){
            System.out.println(e.getMessage());
            return "CLIENTE NÃO EXCLUIDO";
        }
    }
    
}
