CREATE TABLE clinica
(
	id_cli serial,
	nomepet_cli character varying(50),
	nomeresp_cli character varying(50),
	animal_cli character varying(50),
	raca_cli character varying(50),
	rg_cli character varying(50),
	cpf_cli character varying(50),
	numero_cli character varying(50),
	CONSTRAINT clinica_pkey PRIMARY KEY (id_cli),
	CONSTRAINT clinica_cpf_key UNIQUE (cpf_cli)
	
)